/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Settings2, RotateCw, Ban, CheckCircle2, Dice5, Palette, Plus, Minus } from 'lucide-react';

// --- Types ---

interface DieProps {
  value: number;
  isExcluded: boolean;
  color: string;
  onToggleExclude: () => void;
  isRolling: boolean;
}

// --- Components ---

const Die: React.FC<DieProps> = ({ value, isExcluded, color, onToggleExclude, isRolling }) => {
  // Helper to render dots based on value
  const renderDots = (val: number) => {
    const dotPositions = [
      [], // 0 (not used)
      ['center'], // 1
      ['top-right', 'bottom-left'], // 2
      ['top-right', 'center', 'bottom-left'], // 3
      ['top-left', 'top-right', 'bottom-left', 'bottom-right'], // 4
      ['top-left', 'top-right', 'center', 'bottom-left', 'bottom-right'], // 5
      ['top-left', 'top-right', 'middle-left', 'middle-right', 'bottom-left', 'bottom-right'], // 6
    ];

    const positions = dotPositions[val] || [];

    return (
      <div className="relative w-full h-full p-2 grid grid-cols-3 grid-rows-3 gap-1">
        {positions.includes('top-left') && <div className="w-2 h-2 rounded-full bg-current col-start-1 row-start-1" />}
        {positions.includes('top-right') && <div className="w-2 h-2 rounded-full bg-current col-start-3 row-start-1" />}
        {positions.includes('middle-left') && <div className="w-2 h-2 rounded-full bg-current col-start-1 row-start-2" />}
        {positions.includes('center') && <div className="w-2 h-2 rounded-full bg-current col-start-2 row-start-2" />}
        {positions.includes('middle-right') && <div className="w-2 h-2 rounded-full bg-current col-start-3 row-start-2" />}
        {positions.includes('bottom-left') && <div className="w-2 h-2 rounded-full bg-current col-start-1 row-start-3" />}
        {positions.includes('bottom-right') && <div className="w-2 h-2 rounded-full bg-current col-start-3 row-start-3" />}
      </div>
    );
  };

  return (
    <motion.div
      layout
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ 
        scale: 1, 
        opacity: 1,
        rotate: isRolling ? [0, 90, 180, 270, 360] : 0,
        x: isRolling ? [0, -5, 5, -5, 0] : 0,
        y: isRolling ? [0, 5, -5, 5, 0] : 0
      }}
      transition={{ 
        duration: isRolling ? 0.4 : 0.2,
        ease: "easeInOut"
      }}
      onClick={onToggleExclude}
      className={`
        relative w-24 h-24 rounded-2xl cursor-pointer shadow-lg flex items-center justify-center
        transition-all duration-300 border-2
        ${isExcluded 
          ? 'opacity-40 grayscale scale-95 border-dashed border-slate-400 bg-slate-100 text-slate-500' 
          : `border-transparent text-white`
        }
      `}
      style={{ 
        backgroundColor: isExcluded ? undefined : color,
      }}
    >
      {renderDots(value)}
      
      {/* Status Indicator */}
      <div className="absolute -top-2 -right-2 bg-white rounded-full p-0.5 shadow-sm border border-slate-200">
        {isExcluded ? (
          <Ban className="w-4 h-4 text-slate-400" />
        ) : (
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
        )}
      </div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [diceCount, setDiceCount] = useState(6);
  const [selectedColors, setSelectedColors] = useState<string[]>(['#6366f1']); // Default to Indigo
  const [diceValues, setDiceValues] = useState<number[]>([]);
  const [excludedIndices, setExcludedIndices] = useState<Set<number>>(new Set());
  const [isRolling, setIsRolling] = useState(false);

  // Truncate selected colors if they exceed dice count
  useEffect(() => {
    if (selectedColors.length > diceCount) {
      setSelectedColors(prev => prev.slice(0, diceCount));
    }
  }, [diceCount, selectedColors.length]);

  // Initialize dice values
  useEffect(() => {
    const initialValues = Array.from({ length: diceCount }, () => Math.floor(Math.random() * 6) + 1);
    setDiceValues(initialValues);
    setExcludedIndices(new Set());
  }, [diceCount]);

  // Calculate distributed colors
  const distributedColors = Array.from({ length: diceCount }, (_, i) => 
    selectedColors[i % selectedColors.length]
  );

  const toggleColor = (color: string) => {
    setSelectedColors(prev => {
      if (prev.includes(color)) {
        // Don't allow removing the last color
        if (prev.length === 1) return prev;
        return prev.filter(c => c !== color);
      } else {
        // Don't allow more colors than dice
        if (prev.length >= diceCount) return prev;
        return [...prev, color];
      }
    });
  };

  const rollAll = useCallback(() => {
    if (isRolling) return;
    
    setIsRolling(true);
    
    // Simulate rolling animation time
    setTimeout(() => {
      setDiceValues(prev => prev.map((val, idx) => {
        if (excludedIndices.has(idx)) return val;
        return Math.floor(Math.random() * 6) + 1;
      }));
      setIsRolling(false);
    }, 600);
  }, [excludedIndices, isRolling]);

  const toggleExclude = (index: number) => {
    setExcludedIndices(prev => {
      const next = new Set(prev);
      if (next.has(index)) {
        next.delete(index);
      } else {
        next.add(index);
      }
      return next;
    });
  };

  const colors = [
    { name: 'Indigo', value: '#6366f1' },
    { name: 'Emerald', value: '#10b981' },
    { name: 'Rose', value: '#f43f5e' },
    { name: 'Amber', value: '#f59e0b' },
    { name: 'Sky', value: '#0ea5e9' },
    { name: 'Violet', value: '#8b5cf6' },
    { name: 'Orange', value: '#f97316' },
    { name: 'Teal', value: '#14b8a6' },
    { name: 'Pink', value: '#ec4899' },
    { name: 'Slate', value: '#475569' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-100">
      {/* Header */}
      <header className="bg-white border-bottom border-slate-200 py-6 px-4 sticky top-0 z-10 shadow-sm">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-xl shadow-indigo-200 shadow-lg">
              <Dice5 className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Pro Dice Roller</h1>
              <p className="text-slate-500 text-sm font-medium">Precision rolling for any game</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            {/* Dice Count Setting (Stepper) */}
            <div className="flex flex-col gap-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 px-1">Number of Dice</span>
              <div className="flex items-center bg-slate-100 rounded-xl border border-slate-200 overflow-hidden">
                <button 
                  onClick={() => setDiceCount(prev => Math.max(1, prev - 1))}
                  disabled={diceCount <= 1}
                  className="p-3 hover:bg-slate-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                  aria-label="Decrease dice count"
                >
                  <Minus className="w-4 h-4 text-slate-600" />
                </button>
                <div className="w-10 text-center font-bold text-indigo-600 tabular-nums">
                  {diceCount}
                </div>
                <button 
                  onClick={() => setDiceCount(prev => Math.min(10, prev + 1))}
                  disabled={diceCount >= 10}
                  className="p-3 hover:bg-slate-200 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                  aria-label="Increase dice count"
                >
                  <Plus className="w-4 h-4 text-slate-600" />
                </button>
              </div>
            </div>

            {/* Color Picker (Multi-select) */}
            <div className="flex flex-col gap-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 px-1">Colors ({selectedColors.length}/{diceCount})</span>
              <div className="flex items-center gap-2 bg-slate-100 p-2 rounded-xl border border-slate-200">
                <Palette className="w-4 h-4 text-slate-500" />
                <div className="flex gap-1.5">
                  {colors.map(c => {
                    const isSelected = selectedColors.includes(c.value);
                    const canAdd = selectedColors.length < diceCount;
                    const canRemove = selectedColors.length > 1;
                    const isDisabled = !isSelected && !canAdd;

                    return (
                      <button
                        key={c.value}
                        onClick={() => toggleColor(c.value)}
                        disabled={isDisabled}
                        className={`
                          w-6 h-6 rounded-full transition-all duration-200 border-2 relative
                          ${isSelected ? 'border-slate-900 scale-110 shadow-sm' : 'border-transparent hover:scale-105'}
                          ${isDisabled ? 'opacity-20 cursor-not-allowed grayscale' : 'cursor-pointer'}
                        `}
                        style={{ backgroundColor: c.value }}
                        title={c.name}
                      >
                        {isSelected && (
                          <div className="absolute -top-1 -right-1 bg-white rounded-full p-0.5 shadow-xs">
                            <CheckCircle2 className="w-2 h-2 text-slate-900" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-12">
        {/* Dice Grid */}
        <div className="flex flex-wrap justify-center gap-8 mb-16 min-h-[300px] items-center">
          <AnimatePresence mode="popLayout">
            {diceValues.map((val, idx) => (
              <Die
                key={idx}
                value={val}
                isExcluded={excludedIndices.has(idx)}
                color={distributedColors[idx]}
                onToggleExclude={() => toggleExclude(idx)}
                isRolling={isRolling && !excludedIndices.has(idx)}
              />
            ))}
          </AnimatePresence>
        </div>

        {/* Action Button */}
        <div className="flex flex-col items-center gap-4">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={rollAll}
            disabled={isRolling}
            className={`
              flex items-center gap-3 px-12 py-5 rounded-2xl font-bold text-xl shadow-xl transition-all
              ${isRolling 
                ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
                : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-200'
              }
            `}
          >
            <RotateCw className={`w-6 h-6 ${isRolling ? 'animate-spin' : ''}`} />
            {isRolling ? 'Rolling...' : 'Roll All Dice'}
          </motion.button>
          
          <p className="text-slate-400 text-sm font-medium flex items-center gap-2">
            <Ban className="w-3 h-3" />
            Click a die to exclude it from the next roll
          </p>
        </div>
      </main>

      {/* Footer / Stats */}
      <footer className="max-w-5xl mx-auto px-4 py-12 border-t border-slate-200">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-slate-400 text-xs uppercase tracking-widest font-bold mb-2">Total Sum</h3>
            <p className="text-4xl font-black text-slate-800">
              {diceValues.reduce((a, b) => a + b, 0)}
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-slate-400 text-xs uppercase tracking-widest font-bold mb-2">Active Dice</h3>
            <p className="text-4xl font-black text-slate-800">
              {diceCount - excludedIndices.size}
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-slate-400 text-xs uppercase tracking-widest font-bold mb-2">Excluded</h3>
            <p className="text-4xl font-black text-slate-800">
              {excludedIndices.size}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
